//信息栏
//进游戏显示 搬运请勿移除版权等声明信息
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[red]单属体信息栏");
    dialog.cont.image(Core.atlas.find("单属体重置-icon")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("[green]当前版本0.0.4").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("[red]----更新日志------\n[blue]\n0.0.3 目前就是个星球观赏模组");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();//return table;
table.button("[red]Cool", run(() => {//0
    var dialog2 = new BaseDialog("[red]Cool");
    var table = new Table();
	
	var t = new Table();
	t.add("这里什么也没有");
    dialog2.cont.add(new ScrollPane(t)).size(500, 810).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64);//1
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//新科技作者提供